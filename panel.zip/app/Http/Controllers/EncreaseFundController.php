<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EncreaseFundController extends Controller
{
    //
}
