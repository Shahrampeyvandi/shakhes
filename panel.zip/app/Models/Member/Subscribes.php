<?php

namespace App\Models\Member;

use Illuminate\Database\Eloquent\Model;

class Subscribes extends Model
{
    //
}
