<?php

namespace App\Models\CapitalIncrease;

use Illuminate\Database\Eloquent\Model;

class CapitalIncreasePercents extends Model
{
    //
}
