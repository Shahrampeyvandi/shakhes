@extends('layout.temp')

@section('content')
    dfsf
@endsection